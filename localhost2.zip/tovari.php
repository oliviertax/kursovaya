<!DOCTYPE html>
<html>
       <body>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>
Школа английского языка
</title>
<link rel="stylesheet" href="tovari5.css">
<style>
        h {
 font-family: Verdana
}
a {
 font-family: Verdana;
 font-size: 18px
}
p {
 font-family: Verdana
}
       </style>
</head>
 </div>
 <header class="header">
  <nav style="position: relative;left: 50px; " class="nav">
   <a style="position: relative;top: 0px; left: 60px;" class="nav_link" href="Main_menu.html">Главная</a>
   <a  style="position: relative;top: 0px; left: 60px;" class="nav_link" href="tovari.php"> Товары</a>
 </div>
       <nav class="nav_link1">
         <div>
             <p style=" position: relative; left: -340%; top: 15%; font-size: 20px;color: rgb(245, 245, 245);"> Школа Английского Языка</p>
         </div>
<a style="position: relative;top: -65px; left: 750px;" href="registration.php"> Регистрация</a>
       </nav>
</nav>
</header>
     <br>
     <br>
     </div>
     <style>
     </style>
     <br>
     <div style="position: relative; left: 2%;">
     <img style="position: relative; width: 450px;top: 50px;border-radius: 20%; height: 195px;" src="img/tov1.jpg">
     <p style="position: relative; left: 45px;top: 50px; font-size: 25px; ">8 занятий в месяц 2400 руб </p>
</div>
     <div style="position: relative; top: 50px;">
       <img style="position: relative;width: 450px; height: 195px;border-radius: 20%; left: 2%;" src="../img/tov2.jpg">
       <p style="position: relative; left: 78px;font-size: 25px;">8 занятий в месяц 2600 руб </p>
        </div>
        <img style="position: relative;width: 450px; height: 195px;border-radius: 20%;top: -510px; left: 60%;" src="../img/tov3.jpg">
              <p style="position: relative;left: 65%;top: -510px;border-radius: 20%; font-size: 25px;">8 занятий в месяц 2800 руб</p>
              <img style="position: relative;width: 450px; height:195px;border-radius: 20%;top: -510px; left: 60%;" src="../img/tov4.jpg">
              <p style="position: relative;left: 65%;top: -510px;border-radius: 20%; font-size: 25px;">8 занятий в месяц 3000 руб</p>
              <img style="position: relative;width: 450px; height:195px;border-radius: 20%;top: -1070px; left: 120%;" src="../img/tov5.jpg">
              <p style="position: relative;left: 125%;top: -1070px;border-radius: 20%; font-size: 25px;">8 занятий в месяц 3200 руб</p>



              <div style="position: relative;top: -730px; left: 81%;" class="wrapper">
                <input type="checkbox" id="modal">
                <label class="btn" for="modal">ОСТАВИТЬ ЗАЯВКУ</label>

                <form style="position: relative; left: -21%;" action="" class="popup" method="post">
                  Ваше имя
                  <input class=input id="name" name=name type="text">Ваш телефон
                  <input class=input id="tel" name=tel type="text">
                  <input style="width: 254px; height: 27px;" type="submit">
                  <label class="close" for="modal">+</label>
                </form>
              </div>
     	<br>
     </div>
     </div>
		 <div style="position: relative;top: -6600px; left: 81%;" >
     <?php require_once 'db.php';?>
		 </div>
</body>
</html>
