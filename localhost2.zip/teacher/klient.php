<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
     <link rel="stylesheet" href="../style2.css">
	<title>
		Школа английского языка
	</title>
     <style>
	h {
   font-family: Verdana
  }
	a {
   font-family: Verdana;
   font-size: 18px
  }
  p {
   font-family: Verdana
  }

	th, td {
		font-size: 18px;
		padding: 10px;
	}
	th {
		background: #555;
		color: #D3D3D3;
	}
	td {
		background: #eee;
	}
	a {
		text-decoration: none;
		transition: 0.2s ease;
	}
	td:nth-child(7) > a {
		color: #c22a2a;
	}
	a:hover {
		opacity: 0.7;
	}
	input, textarea {
		padding: 10px;
		display: block;
		min-height: 30px;
		width: 250px;
		margin-bottom: 10px;
	}
	textarea {
		resize: vertical;
		height: 50px;
	}

     #left { position: absolute; left: 360px; top: 250px; width: 20%; }
    #right { position: absolute; right: -200px; top: 550px; width: 20%; }
         </style>
</head>
<body>
   </div>
   <header class="header">
    <nav style="position: relative;left: 60px; " class="nav">
     <a class="nav_link" href="Main_menu.html">Главная</a>
     <a class="nav_link" href="tovari.html"> Товары</a>
     <a class="nav_link" href="klient.php"> Клиенты</a>
     <a class="nav_link" href="group.php"> Группы</a>
         <nav class="nav_link1">
<a style="position: relative; left: 440px;" href="profile_teacher.php"> Личный кабинет</a>
         </nav>
       </header>
     <br>
     <br>
     </div>
     <style>
body {
font-family: Arial, Helvetica, sans-serif;
}
     </style>

		 <?php require_once '../vendor/connect.php';?>
	   <table style="position: relative; top: -640px; right: -550px;">
	     <tr>
	       <th>Имя</th>
	       <th>Фамилия</th>
	       <th>Отчество</th>
				 <th>Номер</th>
	       <th>Курс</th>
	       <th>Группа</th>
	       <th>&#10006;</th>
	     </tr>

	     <?php
	       $users = mysqli_query($connect, "SELECT * FROM `users`");
	       $users = mysqli_fetch_all($users);
	     foreach ($users as $user){
	       ?>
	       <tr>
	       <a style=" position: relative; top: -1000px;">  <?= $user[0] ?></a>
	         <th><?= $user[1] ?></th>
	         <th><?= $user[2] ?></th>
	         <th><?= $user[3] ?></th>
	         <th><?= $user[6] ?></th>
	         <th><?= $user[7] ?></th>
			 <th><?= $user[8] ?></th>
	         <td><a href="delete.php?id_user=<?= $user[0] ?>">Удалить</a></td>
	     </tr>
			 <?php
			 }
			 ?>
        </table>
</body>
</html>
