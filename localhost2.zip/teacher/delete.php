<?php
require_once '../vendor/connect.php';

$id_user = $_GET['id_user'];

mysqli_query($connect, "DELETE FROM `users` WHERE `users`.`id` = '$id_user'");

header('Location: klient.php');
