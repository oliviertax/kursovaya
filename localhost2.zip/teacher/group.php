<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<title>
		Школа английского языка
	</title>
     <link rel="stylesheet" href="../style2.css">
     <style>
  h {
   font-family: Verdana
  }
	a {
   font-family: Verdana;
   font-size: 18px
  }
  p {
   font-family: Verdana
  }

	th, td {
		font-size: 18px;
		padding: 10px;
	}
	th {
		background: #555;
		color: #D3D3D3;
	}
	td {
		background: #eee;
	}
	a {
		text-decoration: none;
		transition: 0.2s ease;

	}
	td :nth-child(7) > a {
		color: black;
	}
	a:hover {
		opacity: 0.7;
	}
	input, textarea {
		padding: 10px;
		display: block;
		min-height: 30px;
		width: 250px;
		margin-bottom: 10px;
	}
	textarea {
		resize: vertical;
		height: 80px;
	}
     #left { position: absolute; left: 360px; top: 250px; width: 20%; }
    #right { position: absolute; right: -200px; top: 550px; width: 20%; }
         </style>
</head>
<body>
   </div>
   <header class="header">
    <nav style="position: relative;left: 60px; " class="nav">
     <a class="nav_link" href="Main_menu.html">Главная</a>
     <a class="nav_link" href="tovari.html"> Товары</a>
     <a class="nav_link" href="klient.php"> Клиенты</a>
     <a class="nav_link" href="group.php"> Группы</a>
         <nav class="nav_link1">
<a style="position: relative; left: 440px;" href="profile_teacher.php"> Личный кабинет</a>
         </nav>
       </header>
     </div>
     <style>
body {
font-family: Arial, Helvetica, sans-serif;
}
     </style>

<?php require_once '../vendor/connect.php';?>

		<table style="position: relative;top: -300px; right: -650px;">
			<tr>
				<th>Группа</th>
				<th>Курс</th>
				<th>Количество клиентов</th>
				<th>&#10006;</th>
				<?php
					$obychs = mysqli_query($connect, "SELECT * FROM `group`");
					$obychs = mysqli_fetch_all($obychs);
				foreach ($obychs as $obych){
					?>
					<tr>
						<a style=" position: relative; top: -1000px;">  <?= $obych[0] ?></a>
						<th><?= $obych[1] ?></th>
						<th><?= $obych[2] ?></th>
						<th><?= $obych[3] ?></th>
						<td><a href="delete_group.php?id_group=<?= $obych[0] ?>">Удалить</a></td>
				</tr>
				<?php
				}
				?>
				</table>
</body>
</html>
