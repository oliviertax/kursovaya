<?php
require_once '../vendor/connect.php';

$id_group = $_GET['id_group'];

mysqli_query($connect, "DELETE FROM `group` WHERE `group`.`id_group` = '$id_group'");

header('Location: group.php');
?>
