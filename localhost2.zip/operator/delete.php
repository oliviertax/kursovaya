<?php
require_once '../vendor/connect.php';

$id_zayav = $_GET['id_zayav'];

mysqli_query($connect, "DELETE FROM `zayav` WHERE `zayav`.`id_zayav` = '$id_zayav'");

header('Location: ../operator.php');
?>
